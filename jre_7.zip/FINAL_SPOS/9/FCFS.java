import java.util.*;
public class FCFS
{
  public static void main(String[] args)
  {
    Scanner s = new Scanner(System.in);
    System.out.println("Enter the number of processes");    //Enter no of processes
    int p = s.nextInt();
    int at[] = new int[p];              //Arrival time
    int bt[] = new int[p];              //Burst time
    int wt[] = new int[p];              //waiting time
    int ct[] = new int[p];              //completion time
    int tt[] = new int[p];              //tuenaround time
    int t;
    for(int i = 0;i < p;i++)
    {
      System.out.println("Enter the Arrival Time for process - " + i);    // Arrival time ip
      at[i] = s.nextInt();
      System.out.println("Enter the Burst Time for process - " + i);      //Burst time ip
      bt[i] = s.nextInt();
    }
    for(int i = 0;i < p;i++)      //sort by arrival time
    {
      for(int j = 0;j < p - (i+1);j++)
      {
        if(at[j] > at[j+1])
        {
          t = at[j];
          at[j] = at[j+1];
          at[j+1] = t;
          t = bt[j];
          bt[j] = bt[j+1];
          bt[j+1] = t;
        }
      }
    }
    ct[0] = at[0] + bt[0];  //completion time for very 1st process
    for(int i = 1;i < p;i++)  
    {
      if(at[i] > ct[i-1])     //if process arives after completion time
        ct[i] = at[i] + bt[i];
      else
        ct[i] = ct[i-1] + bt[i];    // normal process which has alredy arrived
    }
    for(int i = 0;i < p;i++)      // turnaround time and waiting time
    {
      tt[i] = ct[i] - at[i];
      wt[i] = tt[i] - bt[i];
    }
    System.out.println("Process\tAT\tBT\tCT\tTT\tWT");   //print everything
    for(int i = 0;i < p;i++)
    {
      System.out.println((i+1) + "\t" + at[i] + "\t" + bt[i] + "\t" + ct[i] + "\t" + tt[i] + "\t" + wt[i]);
    }
  }
}